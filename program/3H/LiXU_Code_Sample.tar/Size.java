package com.st.ime;

public class Size{
    private int w;
    private int h;

    protected void setSize(int w,int h){
        this.w = w;
        this.h = h;
    }

    public int getW(){
        return w;
    }
    public int getH(){
        return h;
    }
}

